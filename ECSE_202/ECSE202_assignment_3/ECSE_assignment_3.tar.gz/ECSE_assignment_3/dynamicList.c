/*
 * NOT DONE DO NOT COMPILE
 * description: code to create a dynamic list
 */
 
 struct node
 {
     int data;
     struct node* head;
 }
 
 static struct node* START;
 
 void addNode()